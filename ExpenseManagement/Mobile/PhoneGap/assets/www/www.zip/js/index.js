var PoC = PoC || {};

var MainApp = function () {
    var expenses = new ZS.model.expenseCollection();
    var dac = new LocalStore();

    /* Compiling templates : Is there a better way? */
    var footerTemplateSource = $('#footerTemplate').html();
    var footerTemplate = Handlebars.compile(footerTemplateSource);

    var source = $('#template').html();
    var expenseTemplate = Handlebars.compile(source);

    var newExpenseSource = $('#newExpenseTemplate').html();
    var newExpenseTemplate = Handlebars.compile(newExpenseSource);

    // Application Constructor
    this.initialize = function () {
        console.log("binding device ready events");
        document.addEventListener("deviceready", onDeviceReady, true);
    };

    var fetchNewDataFromServer = function() {
        if (deviceInfo.IsConnected) {
            //Update the wifi icon
            $('#wifiStatus').addClass("icon-signal");
            ZS.Communication.UserExpenses.GetUserExpenses().done(function (data,textStatus,jqXHR) {
                console.log("data recieved from server");
                console.log(data);
                var newExpensesCount = expenses.ProcessNewServerData(data);
                $('#badgeExpense').html(newExpensesCount);
            }).fail(function (jqXHR,responseText,errorThrown) {
                console.log("request failed" + responseText);
            });
        } else {
            $('#wifiStatus').removeClass("icon-signal");
        }
    };

    var onDeviceReady = function () {

        //dac.Read(expenses);
        //window.navigator.notification.alert("Device Ready");
        console.log("application is ready");
        


        //Fill device details. 
        deviceInfo = new DeviceInfo();
       
       
        var homeView = new ZS.Views.HomeView();
        
        homeView.Render().done(function() {
            $('div#contents').html(this.el);
        });

        ZS.Communication.UserExpenses.GetUserAuthentication("nothing", "nothing").done(function(resposne) {
            console.log(resposne);
        });



        fetchNewDataFromServer();
        $('ul.nav li').on('click', function () {
            $('li.active').removeClass('active');
            $(this).addClass('active');
            //fetchNewDataFromServer();
        });

        $('#navNewExpense').on('click', function () {
            var view = new ZS.Views.NewExpenseView();
            view.Render().done(function() {
                $('div#contents').html(this.el);
            });
            fetchNewDataFromServer();
        });

        $('li#navCurrentExpenses').on('click', function () {
            homeView.Render().done(function() {
                $('div#contents').html(this.el);
            });
            fetchNewDataFromServer();
        });


        $('li#navAuth').on('click', function() {
            var aView = new ZS.Views.AuthView();
            $('div#contents').html(aView.Render().elm);
        });

        $('#navSync').on('click', function () {
            console.log("syncing device");
            expenses.ResyncPendingData();
            dac = new LocalStore();
            dac.Save(expenses).done(function() {
                $('li#navCurrentExpenses').click();
            });
        });
    };
};
